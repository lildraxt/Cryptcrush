CRYPTCRUSH 1.1 - gothic distortion + lowpass
For FL Studio 2024 or newer, 64-bit Windows (CLAP format).

INSTALL
 1. Close FL Studio.
 2. If Windows blocked the download: right-click the zip > Properties > tick "Unblock" > OK,
    then unzip it.
 3. Copy Cryptcrush.clap into:   C:\Program Files\Common Files\CLAP
    (create the CLAP folder if it is missing; Windows will ask for admin permission)
 4. Open FL Studio > Options > Manage plugins > Find installed plugins.
 5. Add Cryptcrush to a mixer effect slot. Star it in the Plugin Manager to keep it in menus.

CONTROLS
 DRIVE       0 to 36 dB of distortion (0 = clean)
 VELVET      smooth, warm saturation
 FANG        lopsided hard clipping, buzzy and aggressive
 HEX         wavefolder, metallic and strange
 CUTOFF      lowpass, 20 Hz to 20 kHz, 24 dB/octave
 RESONANCE   peak at the cutoff
 MIX         dry / wet
 OUTPUT      -24 to +12 dB

 Drag a knob up/down. Shift-drag = fine. Mouse wheel works.
 Double-click or Ctrl-click = reset.
 The bat's eyelids follow Cutoff, its eyes glow with Drive, its mouth follows the level.

AUTOMATION
 Right-click a knob. If FL Studio supplies its menu there, pick Create automation clip.
 If you see the plugin's small backup menu instead, close it, then use
 Tools menu > Last tweaked > Create automation clip (your knob is already selected).

NOTES
 Signal path: distortion (4x oversampled) > lowpass. Latency 48 samples, reported to the host.
 Turn your monitors down while trying high Resonance and Drive.
